=== TrustMeter for Google ===
Contributors: alexf2000
Donate http://alexf.name/2007/08/20/trustmeter-for-google
Tags: SEO, Google, Trust Rank
Requires at least: 2.0
Tested up to: 2.2
Stable tag:

TrustMeter Wordpress plugin - shows where your pages rank for their page titles.

== Description ==

Plugin/Widget for Wordpress that shows how your host is indexed in Google and 
is it "trusted" or not. How it works: first, it is querying Google for 
site:your-blog.com, then it extracts first 10 titles from response and 
qurying Google for this titles. Then it is searching for your blog positions 
in the responses and showing it along with the query as a number, so you 
get 10 numbers as you can see it in my blog. The smaller number is the 
better Google "trusts" to your host. When plugin is installed, you can 
see numbers at your dashboard and also add a widget to show it to your 
visitors. Data are updated automatically every 5 days.

== Installation ==

1. Activate the plugin through the 'Plugins' menu in WordPress
2. Specify host, plugin title and visibility in widget settings menu.

